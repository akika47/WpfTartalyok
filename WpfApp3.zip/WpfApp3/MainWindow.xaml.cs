﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Osztalyaim;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Osztalyaim.Tartaly> tartalyok = new List<Tartaly>();
        public MainWindow()
        {
            InitializeComponent();
            rdoTeglatest.IsChecked = true;
        }

        private void rdoTeglatest_Checked(object sender, RoutedEventArgs e)
        {
            txtAel.Text = "";
            txtBel.Text = "";
            txtCel.Text = "";
            txtAel.IsEnabled = true;
            txtBel.IsEnabled = true;
            txtCel.IsEnabled = true;
        }

        private void rdoKocka_Checked(object sender, RoutedEventArgs e)
        {
            txtAel.Text = "10";
            txtBel.Text = "10";
            txtCel.Text = "10";
            txtAel.IsEnabled = false;
            txtBel.IsEnabled = false;
            txtCel.IsEnabled = false;
        }

        private void btnFelvesz_Click(object sender, RoutedEventArgs e)
        {
            Tartaly ujTest;
            if (rdoKocka.IsChecked == true )
            {
                ujTest = new Tartaly(txtNev.Text);
            }
            else { ujTest = new Tartaly(txtNev.Text, Convert.ToInt32(txtAel.Text), Convert.ToInt32(txtBel.Text), Convert.ToInt32(txtCel.Text)); }

            if (txtNev.Text == "")
            {
                MessageBox.Show("Nem adott nevet!", "NAGY HIBA", MessageBoxButton.OK, MessageBoxImage.Error);                
            }
            else
            {
                lbTartalyok.Items.Add(ujTest.Info());
                tartalyok.Add(ujTest);
            }

        }

        private void btnRogzit_Click(object sender, RoutedEventArgs e)
        {

            StreamWriter sw = new StreamWriter("tartalyok.txt",append: true);
            foreach (Tartaly aktElem in tartalyok)
            {
                String csvsor = $"{aktElem.Nev};{aktElem.aEl};{aktElem.bEl};{aktElem.cEl},{aktElem.AktLiter}";
                sw.WriteLine(csvsor);
            }
            sw.Close();
        }

        private void btnDuplaz_Click(object sender, RoutedEventArgs e)
        {
            if (lbTartalyok.SelectedIndex == -1)
            {
                MessageBox.Show("Nincs kiválasztva semmi!", "NAGY HIBA", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                tartalyok[lbTartalyok.SelectedIndex].DuplazMeretet();
                lbTartalyok.Items[lbTartalyok.SelectedIndex] = tartalyok[lbTartalyok.SelectedIndex].Info();
            }


        }

        private void btntolt_Click(object sender, RoutedEventArgs e)
        {
            if (lbTartalyok.SelectedIndex == -1)
            {
                MessageBox.Show("Nincs kiválasztva semmi!", "NAGY HIBA", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                tartalyok[lbTartalyok.SelectedIndex].Tolt(Convert.ToDouble(txtMennyitTolt.Text));
                lbTartalyok.Items[lbTartalyok.SelectedIndex] = tartalyok[lbTartalyok.SelectedIndex].Info();
            }

        }

        private void btnLeenged_Click(object sender, RoutedEventArgs e)
        {
            if (lbTartalyok.SelectedIndex == -1)
            {
                MessageBox.Show("Nincs kiválasztva semmi!", "NAGY HIBA", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                tartalyok[lbTartalyok.SelectedIndex].TeljesLeengedes();
                lbTartalyok.Items[lbTartalyok.SelectedIndex] = tartalyok[lbTartalyok.SelectedIndex].Info();
            }
        }

        private void txtAel_TextChanged(object sender, TextChangedEventArgs e)
        {
            string tString = txtAel.Text;
            if (tString.Trim() == "") return;
            for (int i = 0; i < tString.Length; i++)
            {
                if (!char.IsNumber(tString[i]))
                {
                    MessageBox.Show("Csak szám lehet az élekben!", "NAGY HIBA", MessageBoxButton.OK, MessageBoxImage.Error);
                    txtAel.Text = "";
                    return;
                }

            }
        }

        private void txtBel_TextChanged(object sender, TextChangedEventArgs e)
        {
            string tString = txtBel.Text;
            if (tString.Trim() == "") return;
            for (int i = 0; i < tString.Length; i++)
            {
                if (!char.IsNumber(tString[i]))
                {
                    MessageBox.Show("Csak szám lehet az élekben!", "NAGY HIBA", MessageBoxButton.OK, MessageBoxImage.Error);
                    txtBel.Text = "";
                    return;
                }

            }
        }

        private void txtCel_TextChanged(object sender, TextChangedEventArgs e)
        {
            string tString = txtCel.Text;
            if (tString.Trim() == "") return;
            for (int i = 0; i < tString.Length; i++)
            {
                if (!char.IsNumber(tString[i]))
                {
                    MessageBox.Show("Csak szám lehet az élekben!", "NAGY HIBA", MessageBoxButton.OK, MessageBoxImage.Error);
                    txtCel.Text = "";
                    return;
                }

            }
        }
    }
}
